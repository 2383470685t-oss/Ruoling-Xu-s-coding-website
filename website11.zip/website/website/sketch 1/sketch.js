let x = 0, y =0
let vx = 0, vy = 0

function setup() {
  createCanvas(1920/2,1080/2);
}

function draw() {
  background(0,5)

filter(BLUR);
  
x = x+  vx
y = y + vy
  
  
 if (y >=height - 10) {
      vy = vy*-0.97
   
    
 }

   if (y <= 10) {
      vy =vy*-0.97
   }

  if (x>= width - 10) {
      vx= vx*-0.97
}

   if (x <= 10) {
      vx =vx* -0.97
  
}

  vx=vx*0.97
  vy=vy*0.97;
 circle(x,y,20);

  
  if (mouseIsPressed === true) {
line(mouseX, mouseY, pmouseX, pmouseY)
    noStroke()   
  circle(mouseX, mouseY, 20)
     

  
  }
}

function mouseReleased() {
  x = mouseX
  y = mouseY
  vx = (mouseX - pmouseX) * 2
vy = (mouseY - pmouseY) * 2

}