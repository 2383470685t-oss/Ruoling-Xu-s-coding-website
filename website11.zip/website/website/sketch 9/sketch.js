let wRect = [] 
let bRect = [] 
let whiteNotes = []
let blackNotes = []

let whiteFreq = [261.63, 293.66, 329.63, 349.23, 392.0, 440.0, 493.88]
let blackFreq = [277.18, 311.13, 349.23, 392.00, 440.00, 493.88]

let osc




function setup() { 
  createCanvas(1920/2, 1080/2); 
  
osc=new p5.Oscillator('sine');
  osc.start()
  osc.amp(0)
  
  
  
  
  for (x = 0; x < 7; x++){
    wRect[x] = 0} 
  
  for (y=0; y<6; y++){ 
    bRect[y] = 0 
 
  } 
} 


function draw() { 
  background(220); 
  
  let w = width/7 
  let h = height 
  
  
  for (let x =0; x<7; x++){ 
    if (wRect[x] == 1) { 
      fill(150) 
    } 
    else { 
      fill(255) 
    } 
    
    rect(x * w, 0, w, h); 
  } 
  
  for (let y =0; y<6; y++){ 
    if (bRect[y] == 1) { 
      fill(80) 
    } 
    else { 
      fill(0) 
  }
    
    rect((y + 1) * w - w / 4, 0, w/2, h * 0.6); 
  
  }

} 

function mousePressed() { 
  
  let w = width/7; 
  let h = height; 
  
  for (let y = 0; y < 6; y++) { 
    if (mouseX > (y + 1) * w - w / 4 && mouseX < (y + 1) * w - w / 4 + w/2 && mouseY < h*0.6) { 
      bRect[y] = 1
      playSound(blackFreq[y])
       return; 
    }; 
   
  } 
  
  for (let x = 0; x < 7; x++) { 
    if (mouseX > x * w && mouseX < (x + 1) * w) { wRect[x] = 1; 
    playSound(whiteFreq[x])
    return;
                                                
 } 
  
  } 

} 

function mouseReleased() { 
  wRect.fill(0); 
  bRect.fill(0)
  osc.amp(0, 0.2)
}


function playSound(freq) {
  osc.freq(freq);
  osc.amp(0.5, 0.05);
}