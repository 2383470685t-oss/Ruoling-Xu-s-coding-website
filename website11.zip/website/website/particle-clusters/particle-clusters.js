let groups = [];

function setup() {
    createCanvas(windowWidth, windowHeight);
    startClusters();
}

function draw() {
    background(8);
    drawClusters();
}

function startClusters() {
    groups = [];
    let G = 11;  
    let per = 40;
    
    for (let i = 0; i < G; i++) {
        let g = {
            id: i,
            x: random(width * 0.15, width * 0.85),
            y: random(height * 0.15, height * 0.85),
            vx: random(-1, 1),  
            vy: random(-1, 1),  
            r: random(60, 120), 
            parts: []
        };
        

        for (let j = 0; j < per; j++) {
            g.parts.push({
                x: g.x + random(-g.r, g.r),
                y: g.y + random(-g.r, g.r),
                vx: random(-1, 1),
                vy: random(-1, 1)
            });
        }
        
        groups.push(g);
    }
}

function drawClusters() {
    for (let g of groups) {
        
        g.x += g.vx;
        g.y += g.vy;
        
    
        if (g.x < g.r || g.x > width - g.r) g.vx *= -1;
        if (g.y < g.r || g.y > height - g.r) g.vy *= -1;
        
    
        for (let p of g.parts) {
        
            p.vx += (g.x - p.x) * 0.001 + random(-0.2, 0.2);
            p.vy += (g.y - p.y) * 0.001 + random(-0.2, 0.2);
            p.x += p.vx;
            p.y += p.vy;
        }

        stroke(255, 100);
        strokeWeight(0.6);
        for (let i = 0; i < g.parts.length; i++) {
            for (let j = i + 1; j < g.parts.length; j++) {
                let a = g.parts[i];
                let b = g.parts[j];
                let d = dist(a.x, a.y, b.x, b.y);
                if (d < 70) {
                    line(a.x, a.y, b.x, b.y);
                }
            }
        }
    
        noStroke();
        fill(255);
        for (let p of g.parts) {
            let size = 3 + noise(p.x * 0.01, p.y * 0.01) * 4;
            circle(p.x, p.y, size);
        }
        
          if (dist(mouseX, mouseY, g.x, g.y) < g.r) {
            fill(255, 40);
            noStroke();
            circle(g.x, g.y, g.r * 2);
        }
    }
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

