let colms = 30
let rows = 30


function setup() {
  createCanvas(1920/2, 1080/2);
}

function draw() {
  background(220);
  
  let col1 = color('#7371BC')
  let col2 = color(255)
  
  for (let x = 0; x < colms; x++){
    for (let y = 0; y < rows; y++){
      
      let d = dist(mouseX, mouseY, x*width/colms, height*y/rows)
      
      let wave = sin(frameCount * 0.01 + d * 0.5)
      
       let i = map(wave, -1, 1, 0, 1)
      let col = lerpColor(col1, col2, i)

      fill(col);
      rect( x*width/colms, height*y/rows, width/colms, height/rows);
      

      
    }
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
}