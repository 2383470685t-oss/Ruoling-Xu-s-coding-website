


let num = 20;
let y
frameRate = 60


function setup() {
  createCanvas(1920/2, 1080/2);
}

function draw() {
  background(30,20);

 

  for (let i = 0; i < num; i++) {
    let t = frameCount * 0.35 - i * 10
    

      y = height / 2 + sin(t * 0.1) * 100


   
    

    fill(255)
    
    noStroke()
    
  ellipse((i + 1) * t, y, 30)
 
  }

}