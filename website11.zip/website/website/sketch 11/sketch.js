let cam

function setup() {
  createCanvas(1920/2,1080/2)
  pixelDensity(1)
  cam = createCapture(VIDEO)
  cam.size(width,height)
  cam.hide
  

}



function draw() {
  background(0)
  cam.loadPixels()
  loadPixels()
  
  
  for(let x =0; x<width;x++){
    for(let y =0; y<height;y++){
      let index= (x+y*width)* 4
    
      let offsetX = int(random(-20, 20))
      let offsetY = int(random(-20, 20))
      let px = constrain(x+ offsetX, 0, width-1)
      let py = constrain(y+ offsetY, 0, height-1)
      let location = (px + py * width) * 4
      
      
      pixels[index+0] = cam.pixels[location+0]
      pixels[index+1] = cam.pixels[location+1]
      pixels[index+2] = cam.pixels[location+2]
      
      pixels[index+3] = 200 +sin(frameCount*0.05+x* 0.02)* 55
    }
    
    
  }
  
  updatePixels()
  
}