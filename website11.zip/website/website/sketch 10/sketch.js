let line
let mic

function setup() {
  createCanvas(1920/2, 1080/2);
  noFill()
  line = new movingLine()

  mic = new p5.AudioIn()
  mic.start()
}

function draw() {
  background(0,20);
  
  let vol = mic.getLevel()
  
  let volume = map(vol, 0, 0.2, 0, 50)
  
  
  line. move(volume);
  line. display();  
}


class movingLine {
  constructor(){
    this.num=random(8,15)
    this.x=[]
    this.y=[]
    
    for (let i=0; i<this.num; i++) {
      this.x[i]=random(width)
      this.y[i]=random(height)
    }
      this.color = random(150, 250);
  }

  
  move(volume){
    for(let i=0; i<this.num; i++){
       this.x[i]+= sin(frameCount*0.01+i)*volume*0.5
      this.y[i]+= cos(frameCount*0.01+i)*volume*0.5
           
   }
      }
      
  
  display(){
    stroke(this.color,200,255)
    strokeWeight(2)
    beginShape()
      for(let i=0;i<this.num; i++){
        vertex(this.x[i],this.y[i])    
      }
   endShape()
    }
    
}
    
  
  
  
  
  
