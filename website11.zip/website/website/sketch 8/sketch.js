let lines = []
let mouseLine = null


function setup() {
  createCanvas(1920/2, 1080/2);
  noFill()

}

function draw() {
  background(0,20);
  for (let all of lines){
  all.move();
  all.display();  
   
    if (mouseLine) {
    mouseLine.update()
    mouseLine.display()
      currentLine = null
  }   
}
}

function  mousePressed(){  
  mouseLine = new movingLine  
  }

function mouseReleased(){
  
  if(mouseLine){
    lines.push(mouseLine)
    mouseLine=null
  }  
}

class movingLine {
  constructor(){
    this.num=0
    this.x=[]
    this.y=[]
    this.color = random(150, 250)

  }

  update(){
     this.x.push(mouseX)
    this.y.push(mouseY)
    this.num = this.x.length    
    
  }
  move(){
    for(let i=0; i<this.num; i++){
       this.x[i]+= sin(frameCount*0.01+i)
      this.y[i]+= cos(frameCount*0.01+i)
           
   }
      }
        
  display(){
    stroke(this.color,200,255)
    strokeWeight(2)
    beginShape()
      for(let i=0;i<this.num; i++){
        vertex(this.x[i],this.y[i])    
      }
   endShape()
    }
    
}
    
  
  
  
  
  
