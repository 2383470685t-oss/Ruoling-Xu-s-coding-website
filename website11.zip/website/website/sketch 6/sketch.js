

let x=[]
let y=[]
let px=[]
let py=[]
let num= 500

function setup() {
  createCanvas(windowWidth, windowHeight);
  stroke(255, 50)
  strokeWeight(2)
  
  for (let i=0; i< num; i++){
    x[i]= random(width)
     y[i]= random(height)
    px[i]=x[i-10]
    py[i]=y[i-10]
    
  }  
    
    
  }


function draw() {
  background(0,20); 
  
  for (let i=0; i< num; i++){
    let n=noise(x[i]*0.005, y[i]*0.005, frameCount*0.005)
  
  x[i] += cos(2*n*PI)*2
    y[i] += sin(n*PI)*2
  
   line(px[i],py[i],x[i],y[i])
  
   px[i] = x[i];
    py[i] = y[i];
  
      }
  }
  
  
  
  
  
  