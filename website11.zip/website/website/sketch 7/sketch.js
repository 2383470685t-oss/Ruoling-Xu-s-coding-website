

let xVals=[]
let yVals=[]
let numSegments = 50

function setup() {
  createCanvas(windowWidth, windowHeight);
  
  for (let i =0; i<numSegments; i++){
    xVals[i]= width/2
    yVals[i]= height/2
}

noStroke()

}


function draw() {
  background(30)
  
  xVals[numSegments-1]= mouseX
  yVals[numSegments-1]= mouseY
  
  for(let i=0; i< numSegments-1; i++){
    xVals[i]= lerp(xVals[i],xVals[i+1],0.2)
    yVals[i]= lerp(yVals[i],yVals[i+1],0.2)
    
    let c= lerpColor(color(255,100,50,200),color(50,150,255,50), i/numSegments)
    fill(c)
    
    
    ellipse(xVals[i],yVals[i],map(i,0,numSegments,2,20))
    
  }
}