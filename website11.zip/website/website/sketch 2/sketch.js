function setup() {
createCanvas(1920/2,1080/2);
  frameRate(4);
}



function draw() {
  
  
  
background(random(120,255));
stroke(0)
strokeWeight(2);
fill(0);

  
let X = random(50,width-50);
let Y = random(100,height-100);

let X1 = random(-50,50);
 let Y1 = random(-40,40)
  
let X2 = random(-50,50);
let Y2 = random(-40,40)

let X3 = random(-40,40);
let Y3 = random(40,80)

let X4 = random(-40,40);
let Y4 = random(40,80)
  
  
circle(X, Y-35, 15)
 line(X,Y-30,X,Y+ 30)
line(X,Y-20,X+ X1,Y+Y1)
 line(X,Y- 20,X+X2,Y+Y2)
line(X,Y+30,X +X3,Y+Y3)
line(X,Y+30,X+X4,Y+Y4)
}
